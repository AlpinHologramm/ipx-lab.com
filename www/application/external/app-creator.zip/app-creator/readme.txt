=== APP CREATOR ===
Contributors: App Creator
Tags: app creator, connector, wordpress
Requires at least: 2.8
Tested up to: 3.5.2
Stable tag: 1.0.0

A JSON API for App Creator

== Description ==

Connect easily your app with your Wordpress!

== Installation ==

1. Install directly App Creator through the plugin installer or upload the "app-creator" folder to the "/wp-content/plugins/" directory
2. Activate the plugin by using the link provided by the plugin installer or through the "Plugins" menu in your WordPress.
